from flask import Flask, render_template, request

app = Flask(__name__)

# Ruta principal para la página de inicio
@app.route("/", methods=["GET", "POST"])
def index():
    fahrenheit = None
    if request.method == "POST":
        try:
            # Obtiene el valor en Celsius ingresado por el usuario
            celsius = float(request.form["celsius"])
            # Realiza la conversión a Fahrenheit
            fahrenheit = (celsius * 9/5) + 32
        except ValueError:
            fahrenheit = "Entrada no válida. Por favor, ingresa un número."

    return render_template("index.html", fahrenheit=fahrenheit)

if __name__ == "__main__":
    app.run(debug=True)
